﻿//****************************************************************************
// Description:
// Author: hiramtan@live.com
//***************************************************************************

namespace HiFramework
{
    interface IFramework:ITick
    {
        void Init();
    }
}
