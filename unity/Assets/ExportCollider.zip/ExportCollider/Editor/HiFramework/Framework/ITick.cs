﻿//****************************************************************************
// Description:
// Author: hiramtan@live.com
//***************************************************************************

namespace HiFramework
{
    public interface ITick
    {
        void Tick();
    }
}
