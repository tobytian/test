﻿//****************************************************************************
// Description:
// Author: hiramtan@live.com
//****************************************************************************

namespace HiFramework
{
    public interface IComponent
    {
        //当取消注册时
        void UnRegistComponent();
    }
}
