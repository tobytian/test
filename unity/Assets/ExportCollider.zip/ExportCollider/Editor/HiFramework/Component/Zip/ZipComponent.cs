﻿/****************************************************************
 * Description: 
 * 
 * Author: hiramtan@live.com
 *////////////////////////////////////////////////////////////////////////


namespace HiFramework
{
    class ZipComponent
    {
    }
}
